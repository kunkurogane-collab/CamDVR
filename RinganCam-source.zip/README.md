# RinganCam

Viewer CCTV ringan (ONVIF/RTSP): live grid, layar penuh, PTZ, snapshot, playback SD card (ONVIF Profile G).

## Build APK lewat GitHub Actions
1. Push project ini ke repo GitHub (branch `main`).
2. Buka tab **Actions** -> workflow **Build APK** (jalan otomatis tiap push, atau klik *Run workflow*).
3. Setelah selesai, unduh APK di bagian **Artifacts** -> `RinganCam-apk`.
4. Untuk rilis: buat tag, mis. `git tag v1.0 && git push --tags` -> APK muncul di **Releases**.

APK ditandatangani dengan debug key (cukup untuk pemakaian pribadi). Untuk rilis resmi, ganti dengan keystore sendiri.

## Pemakaian
Tekan **+ Kamera**, isi IP, port ONVIF, username dan password kamera. Tahan lama pada tile = HD/hemat data.
