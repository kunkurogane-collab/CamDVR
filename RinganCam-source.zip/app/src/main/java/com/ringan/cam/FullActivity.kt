package com.ringan.cam

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.ui.PlayerView
import org.json.JSONArray

/** Layar penuh satu kamera (stream HD). Ketuk layar = tampil/sembunyi tombol PTZ. Back = keluar. */
class FullActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var cam: Cam

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val a = JSONArray(getSharedPreferences("c", MODE_PRIVATE).getString("list", "[]"))
        val i = intent.getIntExtra("i", 0)
        if (i >= a.length()) { finish(); return }
        cam = Cam.from(a.getJSONObject(i))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val pv = PlayerView(this).apply { useController = false; setBackgroundColor(Color.BLACK) }
        val ptz = LinearLayout(this).apply {
            setBackgroundColor(0x66000000)
            listOf("◀" to (-0.5f to 0f), "▲" to (0f to 0.5f), "▼" to (0f to -0.5f), "▶" to (0.5f to 0f)).forEach { (t, v) ->
                addView(Button(context).apply {
                    text = t
                    setOnTouchListener { _, e ->
                        when (e.action) {
                            MotionEvent.ACTION_DOWN -> Thread { runCatching { Onvif.move(cam, v.first, v.second) } }.start()
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> Thread { runCatching { Onvif.stop(cam) } }.start()
                        }
                        true
                    }
                })
            }
        }
        pv.setOnClickListener { ptz.visibility = if (ptz.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        val root = FrameLayout(this).apply {
            addView(pv, FrameLayout.LayoutParams(-1, -1))
            addView(ptz, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, 32, 32) })
        }
        setContentView(root)

        val p = ExoPlayer.Builder(this).setLoadControl(
            DefaultLoadControl.Builder().setBufferDurationsMs(1000, 2000, 250, 500).build()).build()
        pv.player = p
        p.setMediaSource(RtspMediaSource.Factory().setForceUseRtpTcp(true)
            .createMediaSource(MediaItem.fromUri(cam.urls.first())))  // stream utama (HD)
        p.prepare(); p.playWhenReady = true
        player = p
    }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onStop() { super.onStop(); player?.release(); player = null; finish() }
}
