package com.ringan.cam

import android.app.Activity
import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

/** Playback rekaman SD card lewat ONVIF Profile G (FindRecordings + GetReplayUri). */
class PlaybackActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var cam: Cam
    private var rec: Onvif.Rec? = null
    private var url = ""
    private var sel = 0L
    private lateinit var status: TextView
    private lateinit var bar: SeekBar
    private lateinit var pv: PlayerView
    private val fmt = SimpleDateFormat("dd MMM yyyy HH:mm:ss", Locale.getDefault())

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { f() }; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val a = JSONArray(getSharedPreferences("c", MODE_PRIVATE).getString("list", "[]"))
        val i = intent.getIntExtra("i", 0)
        if (i >= a.length()) { finish(); return }
        cam = Cam.from(a.getJSONObject(i))

        status = TextView(this).apply { setTextColor(Color.WHITE); setPadding(24, 16, 24, 16); text = "Mencari rekaman SD card…" }
        pv = PlayerView(this).apply { useController = false }
        bar = SeekBar(this).apply {
            max = 1000; isEnabled = false
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) {
                    rec?.let { if (user) { sel = it.from + (it.to - it.from) * p / 1000; show() } }
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { play() }
            })
        }
        val row = LinearLayout(this).apply {
            addView(btn("-10 mnt") { jump(-600000) }); addView(btn("+10 mnt") { jump(600000) })
            addView(btn("Tanggal") { pickDate() })
            addView(btn("⏯") { player?.let { it.playWhenReady = !it.playWhenReady } })
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK)
            addView(status); addView(pv, LinearLayout.LayoutParams(-1, 0, 1f)); addView(bar); addView(row)
        })

        Thread {
            val r = runCatching {
                val l = Onvif.recordings(cam)
                require(l.isNotEmpty()) { "Tidak ada rekaman terdeteksi" }
                val rc = l.maxBy { it.to }
                rc to Onvif.replayUri(cam, rc.token)
            }
            runOnUiThread {
                r.onSuccess { (rc, u) ->
                    rec = rc; url = u; bar.isEnabled = true
                    sel = maxOf(rc.from, rc.to - 600000); sync(); play()
                }.onFailure {
                    status.text = "Gagal: ${it.message}\nKamera mungkin tidak mendukung ONVIF Profile G (pencarian rekaman), atau SD card kosong."
                }
            }
        }.start()
    }

    private fun show() { rec?.let { status.text = "Rekaman: ${fmt.format(it.from)} – ${fmt.format(it.to)}\nPosisi: ${fmt.format(sel)}" } }
    private fun sync() { rec?.let { bar.progress = ((sel - it.from) * 1000 / (it.to - it.from)).toInt() }; show() }
    private fun jump(d: Long) { rec?.let { sel = (sel + d).coerceIn(it.from, it.to - 1000); sync(); play() } }

    private fun pickDate() {
        val r = rec ?: return
        val c = Calendar.getInstance().apply { timeInMillis = sel }
        DatePickerDialog(this, { _, y, m, d ->
            val t = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0) }.timeInMillis
            sel = t.coerceIn(r.from, r.to - 1000); sync(); play()
        }, c[Calendar.YEAR], c[Calendar.MONTH], c[Calendar.DAY_OF_MONTH]).show()
    }

    private fun play() {
        val r = rec ?: return
        player?.release()
        val p = ExoPlayer.Builder(this).build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) { status.append("\nError: ${e.errorCodeName}") }
        })
        pv.player = p
        p.setMediaSource(RtspMediaSource.Factory().setForceUseRtpTcp(true).createMediaSource(MediaItem.fromUri(url)))
        p.seekTo(sel - r.from)   // offset (npt) dari awal rekaman
        p.prepare(); p.playWhenReady = true
        player = p
    }

    override fun onStop() { super.onStop(); player?.release(); player = null; finish() }
}
