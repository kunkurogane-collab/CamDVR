package com.ringan.cam

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.os.*
import android.provider.MediaStore
import android.text.InputType
import android.view.*
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.ui.PlayerView
import org.json.JSONArray

class MainActivity : Activity() {
    private var cams = mutableListOf<Cam>()
    private val players = mutableListOf<ExoPlayer>()
    private val views = mutableListOf<PlayerView>()
    private val hd = mutableSetOf<Int>()
    private var sel = 0
    private lateinit var grid: GridLayout
    private val prefs by lazy { getSharedPreferences("c", MODE_PRIVATE) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { f() }; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
    }
    private fun ptzBtn(t: String, x: Float, y: Float) = Button(this).apply {
        text = t; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        setOnTouchListener { _, e ->
            val c = cams.getOrNull(sel)
            if (c != null) when (e.action) {
                MotionEvent.ACTION_DOWN -> Thread { runCatching { Onvif.move(c, x, y) } }.start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> Thread { runCatching { Onvif.stop(c) } }.start()
            }
            true
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val top = LinearLayout(this).apply { addView(btn("+ Kamera") { addDialog() }); addView(btn("Hapus") { delSel() }) }
        grid = GridLayout(this).apply { columnCount = 2 }
        val ctl = LinearLayout(this).apply {
            addView(ptzBtn("◀", -0.5f, 0f)); addView(ptzBtn("▲", 0f, 0.5f))
            addView(ptzBtn("▼", 0f, -0.5f)); addView(ptzBtn("▶", 0.5f, 0f)); addView(btn("Foto") { snap() }); addView(btn("⛶") { full() }); addView(btn("SD") { playback() })
        }
        root.addView(top)
        root.addView(ScrollView(this).apply { addView(grid) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(ctl)
        setContentView(root)
    }

    override fun onStart() { super.onStart(); load(); build() }
    override fun onStop() { super.onStop(); release() }

    private fun load() {
        cams = runCatching {
            val a = JSONArray(prefs.getString("list", "[]"))
            MutableList(a.length()) { Cam.from(a.getJSONObject(it)) }
        }.getOrDefault(mutableListOf())
    }
    private fun save() = prefs.edit().putString("list", JSONArray(cams.map { it.json() }).toString()).apply()

    private fun release() { players.forEach { it.release() }; players.clear(); views.clear() }

    private fun build() {
        release(); grid.removeAllViews()
        if (sel >= cams.size) sel = 0
        val w = resources.displayMetrics.widthPixels / 2
        cams.forEachIndexed { i, c ->
            val p = ExoPlayer.Builder(this).setLoadControl(
                DefaultLoadControl.Builder().setBufferDurationsMs(1000, 2000, 250, 500).build()).build()
            val pv = PlayerView(this).apply { useController = false; player = p; setPadding(3, 3, 3, 3) }
            val url = if (i in hd) c.urls.first() else c.urls.last()
            p.setMediaSource(RtspMediaSource.Factory().setForceUseRtpTcp(true).createMediaSource(MediaItem.fromUri(url)))
            p.prepare(); p.playWhenReady = true
            pv.setOnClickListener { sel = i; mark() }
            pv.setOnLongClickListener { if (!hd.add(i)) hd.remove(i); toast(if (i in hd) "HD" else "Hemat data"); build(); true }
            players += p; views += pv
            grid.addView(pv, GridLayout.LayoutParams().apply { width = w; height = w * 9 / 16 })
        }
        mark()
    }

    private fun mark() = views.forEachIndexed { i, v ->
        v.setBackgroundColor(if (i == sel) Color.CYAN else Color.DKGRAY)
        players[i].volume = if (i == sel) 1f else 0f
    }

    private fun full() {
        if (cams.isEmpty()) return
        startActivity(android.content.Intent(this, FullActivity::class.java).putExtra("i", sel))
    }

    private fun playback() {
        if (cams.isEmpty()) return
        startActivity(android.content.Intent(this, PlaybackActivity::class.java).putExtra("i", sel))
    }

    private fun delSel() { if (cams.isNotEmpty()) { cams.removeAt(sel); save(); build() } }

    private fun addDialog() {
        fun et(h: String, d: String = "", pw: Boolean = false) = EditText(this).apply {
            hint = h; setText(d); setSingleLine()
            if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val name = et("Nama", "Kamera ${cams.size + 1}"); val ip = et("IP (mis. 192.168.110.119)")
        val port = et("Port ONVIF", "8899"); val user = et("Username", "admin"); val pass = et("Password", "", true)
        val lay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0)
            listOf(name, ip, port, user, pass).forEach { addView(it) }
        }
        AlertDialog.Builder(this).setTitle("Tambah kamera").setView(lay)
            .setPositiveButton("Simpan") { _, _ ->
                val h = ip.text.toString().trim(); val pt = port.text.toString().toIntOrNull() ?: 80
                val u = user.text.toString(); val p = pass.text.toString()
                toast("Menghubungi kamera…")
                Thread {
                    val r = runCatching { Onvif.discover(h, pt, u, p) }
                    runOnUiThread {
                        val cam = r.getOrNull()?.let { Cam(name.text.toString(), h, pt, u, p, it.first, it.second) }
                            ?: Cam(name.text.toString(), h, pt, u, p, "",
                                listOf("rtsp://$u:$p@$h:554/onvif1")).also { toast("ONVIF gagal (${r.exceptionOrNull()?.message}), pakai URL tebakan") }
                        cams.add(cam); save(); build()
                    }
                }.start()
            }.setNegativeButton("Batal", null).show()
    }

    private fun snap() {
        val v = views.getOrNull(sel)?.videoSurfaceView as? SurfaceView ?: return
        val bmp = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        PixelCopy.request(v, bmp, { r ->
            if (r == PixelCopy.SUCCESS) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "cam_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RinganCam")
                }
                contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)?.let { u ->
                    contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                }
                toast("Foto tersimpan")
            }
        }, Handler(Looper.getMainLooper()))
    }
}
