package com.ringan.cam

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*

data class Cam(val name: String, val host: String, val port: Int, val user: String, val pass: String,
               val token: String, val urls: List<String>) {
    fun json() = JSONObject().put("n", name).put("h", host).put("p", port).put("u", user)
        .put("w", pass).put("t", token).put("r", JSONArray(urls))
    companion object {
        fun from(o: JSONObject) = Cam(o.getString("n"), o.getString("h"), o.getInt("p"), o.getString("u"),
            o.getString("w"), o.getString("t"), o.getJSONArray("r").let { a -> List(a.length()) { a.getString(it) } })
    }
}

object Onvif {
    private const val WSSE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
    private const val WSU = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"
    private const val PROF = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0"

    private fun soap(url: String, user: String, pass: String, body: String): String {
        val nonce = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val created = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
        val md = MessageDigest.getInstance("SHA-1")
        md.update(nonce); md.update(created.toByteArray()); md.update(pass.toByteArray())
        val b64 = { b: ByteArray -> Base64.encodeToString(b, Base64.NO_WRAP) }
        val xml = """<?xml version="1.0" encoding="utf-8"?><s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
<s:Header><Security xmlns="$WSSE"><UsernameToken><Username>$user</Username>
<Password Type="$PROF#PasswordDigest">${b64(md.digest())}</Password>
<Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">${b64(nonce)}</Nonce>
<Created xmlns="$WSU">$created</Created></UsernameToken></Security></s:Header>
<s:Body>$body</s:Body></s:Envelope>"""
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 4000; c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8")
        c.outputStream.use { it.write(xml.toByteArray()) }
        val ok = c.responseCode < 400
        val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) throw RuntimeException("HTTP ${c.responseCode}")
        return text
    }

    private fun withCred(uri: String, u: String, p: String): String {
        if (uri.contains("@")) return uri
        val e = { s: String -> URLEncoder.encode(s, "UTF-8") }
        return uri.replaceFirst("rtsp://", "rtsp://${e(u)}:${e(p)}@")
    }

    /** Return (profileToken pertama, daftar URL RTSP: [0]=utama/HD ... [last]=sub-stream) */
    fun discover(h: String, port: Int, u: String, p: String): Pair<String, List<String>> {
        val base = "http://$h:$port/onvif/device_service"
        val prof = soap(base, u, p, """<GetProfiles xmlns="http://www.onvif.org/ver10/media/wsdl"/>""")
        val tokens = Regex("""<(?:\w+:)?Profiles[^>]*token="([^"]+)"""").findAll(prof).map { it.groupValues[1] }.toList()
        require(tokens.isNotEmpty()) { "Profil tidak ditemukan" }
        val urls = tokens.map { t ->
            val r = soap(base, u, p, """<GetStreamUri xmlns="http://www.onvif.org/ver10/media/wsdl"><StreamSetup>
<Stream xmlns="http://www.onvif.org/ver10/schema">RTSP-Unicast</Stream><Transport xmlns="http://www.onvif.org/ver10/schema"><Protocol>RTSP</Protocol></Transport>
</StreamSetup><ProfileToken>$t</ProfileToken></GetStreamUri>""")
            val uri = Regex("""<(?:\w+:)?Uri>([^<]+)</""").find(r)!!.groupValues[1].replace("&amp;", "&")
            withCred(uri, u, p)
        }
        return tokens[0] to urls
    }

    private fun ptz(c: Cam, body: String) {
        val ns = "http://www.onvif.org/ver20/ptz/wsdl"
        try { soap("http://${c.host}:${c.port}/onvif/device_service", c.user, c.pass, body.replace("NS", ns)) }
        catch (e: Exception) { soap("http://${c.host}:${c.port}/onvif/ptz_service", c.user, c.pass, body.replace("NS", ns)) }
    }

    fun move(c: Cam, x: Float, y: Float) = ptz(c,
        """<ContinuousMove xmlns="NS"><ProfileToken>${c.token}</ProfileToken><Velocity>
<PanTilt xmlns="http://www.onvif.org/ver10/schema" x="$x" y="$y"/></Velocity></ContinuousMove>""")

    fun stop(c: Cam) = ptz(c,
        """<Stop xmlns="NS"><ProfileToken>${c.token}</ProfileToken><PanTilt>true</PanTilt><Zoom>true</Zoom></Stop>""")

    data class Rec(val token: String, val from: Long, val to: Long)

    private fun svc(c: Cam, ns: String): String {
        val base = "http://${c.host}:${c.port}/onvif/device_service"
        return runCatching {
            val r = soap(base, c.user, c.pass, """<GetServices xmlns="http://www.onvif.org/ver10/device/wsdl"><IncludeCapability>false</IncludeCapability></GetServices>""")
            Regex("""<(?:\w+:)?Namespace>\s*${Regex.escape(ns)}\s*</(?:\w+:)?Namespace>\s*<(?:\w+:)?XAddr>([^<]+)<""")
                .find(r)?.groupValues?.get(1)
        }.getOrNull() ?: base
    }

    private fun time(t: String): Long {
        val m = Regex("""(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(?:\.\d+)?(Z|[+-]\d\d:\d\d)?""").find(t) ?: return 0L
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        var ms = f.parse(m.groupValues[1])!!.time
        val z = m.groupValues[2]
        if (z.length == 6) ms -= (if (z[0] == '-') -1 else 1) * (z.substring(1, 3).toLong() * 60 + z.substring(4).toLong()) * 60000
        return ms
    }

    /** Daftar rekaman di SD card (ONVIF Profile G: FindRecordings) */
    fun recordings(c: Cam): List<Rec> {
        val s = svc(c, "http://www.onvif.org/ver10/search/wsdl")
        val ns = "http://www.onvif.org/ver10/search/wsdl"
        val f = soap(s, c.user, c.pass, """<FindRecordings xmlns="$ns"><Scope/><KeepAliveTime>PT30S</KeepAliveTime></FindRecordings>""")
        val tok = Regex("""<(?:\w+:)?SearchToken>([^<]+)<""").find(f)?.groupValues?.get(1) ?: error("Search service tidak merespons")
        val r = soap(s, c.user, c.pass, """<GetRecordingSearchResults xmlns="$ns"><SearchToken>$tok</SearchToken><MinResults>1</MinResults><MaxResults>50</MaxResults><WaitTime>PT5S</WaitTime></GetRecordingSearchResults>""")
        return Regex("""<(?:\w+:)?RecordingInformation>(.*?)</(?:\w+:)?RecordingInformation>""", RegexOption.DOT_MATCHES_ALL)
            .findAll(r).mapNotNull { m ->
                val x = m.groupValues[1]
                fun g(n: String) = Regex("""<(?:\w+:)?$n>([^<]+)<""").find(x)?.groupValues?.get(1)
                val t = g("RecordingToken") ?: return@mapNotNull null
                Rec(t, time(g("EarliestRecording") ?: ""), time(g("LatestRecording") ?: ""))
            }.filter { it.to > it.from }.toList()
    }

    fun replayUri(c: Cam, token: String): String {
        val ns = "http://www.onvif.org/ver10/replay/wsdl"
        val r = soap(svc(c, ns), c.user, c.pass, """<GetReplayUri xmlns="$ns"><StreamSetup>
<Stream xmlns="http://www.onvif.org/ver10/schema">RTP-Unicast</Stream><Transport xmlns="http://www.onvif.org/ver10/schema"><Protocol>RTSP</Protocol></Transport>
</StreamSetup><RecordingToken>$token</RecordingToken></GetReplayUri>""")
        val uri = Regex("""<(?:\w+:)?Uri>([^<]+)</""").find(r)?.groupValues?.get(1)?.replace("&amp;", "&") ?: error("Replay URI kosong")
        return withCred(uri, c.user, c.pass)
    }
}
